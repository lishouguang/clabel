package com.meizu.bi.nlp.nwd.helper;

import java.io.File;

public class Constants {

	public static final String JOB_CONF_MIN_AGGREGATION = "min_aggregation";
	public static final String JOB_CONF_MIN_ENTROPY = "min_entropy";
	public static final String JOB_CONF_MAX_WORD_LENGTH = "max_word_length";
	public static final String JOB_CONF_MIN_WORD_FREQ = "min_word_freq";
	
	public static final String JOB_CONF_WORD_TOTAL = "word_total";
	
	public static final double DEFAULT_MIN_AGGREGATION = 100;
	public static final double DEFAULT_MIN_ENTROPY = 2;
	public static final int DEFAULT_MAX_WORD_LENGTH = 2;
	public static final int DEFAULT_MIN_WORD_FREQ = 50;
	
	public static final String DB_ROOT = "db";
	public static final String DB_ROOT_ZIP = "db.zip";
	public static final String DB_NAME = "nwd.db";
	public static final String DB_FILE_NAME = DB_ROOT + File.separator + DB_NAME;
	public static final String DB_MAP_COUNT = "countmap";
	public static final String DB_MAP_AGGREGATION = "aggregationmap";
	public static final String DB_MAP_ENTROPY = "entropymap";
	public static final String DB_MAP_WORD = "wordmap";
	
	public static final String COUNTER_GROUP = "nwd";
	public static final String COUNTER_CHAR_TOTAL = "chartotal";
	public static final String COUNTER_ENTROPY_TOTAL = "entropytotal";
	
	static {
		File file = new File(DB_ROOT);
		if(!file.exists()) {
			file.mkdirs();
		}
	}
	
}
