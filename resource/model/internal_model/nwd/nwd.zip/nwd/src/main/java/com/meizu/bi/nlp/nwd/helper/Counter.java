package com.meizu.bi.nlp.nwd.helper;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Counter {
	
	private Map<String, Long> map = new HashMap<String, Long>();
	
	public void update(String key) {
		if(map.containsKey(key)) {
			map.put(key, map.get(key) + 1);
		} else {
			map.put(key, 1l);
		}
	}
	
	public long get(String key) {
		return map.containsKey(key) ? map.get(key) : 0;
	}
	
	public long sum() {
		long sum = 0;
		
		Set<Entry<String, Long>> entries = map.entrySet();
		for(Entry<String, Long> entry: entries) {
			sum += entry.getValue();
		}
		
		return sum;
	}
	
	public Set<Entry<String,Long>> entrySet() {
		return map.entrySet();
	}
	
	public void reset() {
		map = new HashMap<String, Long>();
	}

	public static void main(String[] args) {
		Counter counter = new Counter();
		counter.update("a");
		counter.update("a");
		counter.update("b");
		counter.update("b");
		counter.update("b");
		
		System.out.println(counter.get("a"));
		System.out.println(counter.get("b"));
		System.out.println(counter.get("c"));
		
		System.out.println("sum: " + counter.sum());
	}

}
