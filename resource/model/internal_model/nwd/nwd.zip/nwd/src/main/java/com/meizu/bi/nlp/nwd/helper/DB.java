package com.meizu.bi.nlp.nwd.helper;

import java.io.File;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Set;

import jdbm.PrimaryMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;

public class DB {
	
	private RecordManager recordManager = null;
	
	public DB(String dbfile) throws IOException {
		this.recordManager = RecordManagerFactory.createRecordManager(dbfile);
	}
	
	public <K, V> DBMap<K, V> loadOrCreateHashMap(String mapname, Class<K> k, Class<V> v) throws Exception {
		return new DBMap<K, V>("hashmap", mapname, this);
	}
	
	public <K, V> DBMap<K, V> loadOrCreateTreeMap(String mapname, Class<K> k, Class<V> v) throws Exception {
		return new DBMap<K, V>("treemap", mapname, this);
	}
	
	public void close() throws IOException {
		this.recordManager.commit();
		this.recordManager.close();
	}
	
	public static class DBMap<k, v> {
		
		private DB db = null;
		
		private PrimaryMap<Object, Object> map = null;
		
		private DBMap(String maptype, String mapname, DB db) throws Exception {
			this.db = db;
			
			if("treemap".equals(maptype)) {
			} else {
				this.map = db.recordManager.hashMap(mapname);
			}
		}
		
		public void put(k key, v value) {
			this.map.put(key, value);
		}
		
		@SuppressWarnings("unchecked")
		public v get(k key) {
			return (v) this.map.get(key);
		}
		
		public Set<Entry<Object, Object>> entrySet() {
			return this.map.entrySet();
		}
		
		public void commit() throws IOException {
			db.recordManager.commit();
		}
	}
	
	public static void main(String[] args) throws Exception {
		DB db = new DB("db" + File.separator + "nwd.db");
		
		DBMap<String, Double> map = db.loadOrCreateHashMap("cmap", String.class, Double.class);
		map.put("a", 1.0);
		map.put("b", 2.0);
		map.commit();
		System.out.println(map.get("a"));
		System.out.println(map.get("b"));
		
		db.close();
	}

}
