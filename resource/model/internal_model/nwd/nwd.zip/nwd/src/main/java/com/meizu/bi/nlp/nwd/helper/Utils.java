package com.meizu.bi.nlp.nwd.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.mapdb.DB;
import org.mapdb.DBMaker;

public class Utils {

	private static final String CLEAN_REG_STR = "[\\s,.<>\\?:;'\"\\[\\]\\{\\}\\(\\|)~!@#$%^&*\\-_=+，。《》、？：；“”‘’｛｝【】（）…￥！—┄－]+";

	public static double getEnvMinEntropy() {
		String min_entropy_str = System.getenv(Constants.JOB_CONF_MIN_ENTROPY);
		return min_entropy_str != null ? Double.parseDouble(min_entropy_str) : Constants.DEFAULT_MIN_ENTROPY;
	}

	public static double getEnvMinAggregation() {
		String min_aggregation_str = System.getenv(Constants.JOB_CONF_MIN_AGGREGATION);
		return min_aggregation_str != null ? Double.parseDouble(min_aggregation_str)
		        : Constants.DEFAULT_MIN_AGGREGATION;
	}

	public static int getEnvMaxWordLength() {
		String max_word_length_str = System.getenv(Constants.JOB_CONF_MAX_WORD_LENGTH);
		return max_word_length_str != null ? Integer.parseInt(max_word_length_str) : Constants.DEFAULT_MAX_WORD_LENGTH;
	}
	
	public static int getEnvMinWordFreq() {
		String min_word_freq = System.getenv(Constants.JOB_CONF_MIN_WORD_FREQ);
		return min_word_freq != null ? Integer.parseInt(min_word_freq) : Constants.DEFAULT_MIN_WORD_FREQ;
	}

	public static String clean(String str) {
		if (str == null) {
			return null;
		}

		return str.replaceAll(CLEAN_REG_STR, " ").trim();
	}

	public static DB openDB() {
		return DBMaker.newFileDB(new File(Constants.DB_FILE_NAME)).transactionDisable().mmapFileEnable().make();
	}
	
	public static void iterFile(String path, FileProcessor processor) throws Exception {
		FileSystem fs = null;
		try{
			Path file = new Path(path);
			fs = FileSystem.get(new Configuration());
			if(fs.isDirectory(file)) {
				for(FileStatus fstatus: fs.listStatus(file)) {
					readFile(processor, fs, fstatus.getPath());
				}
			} else {
				readFile(processor, fs, file);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if(fs != null) {
				fs.close();
			}
		}
	}

	private static void readFile(FileProcessor processor, FileSystem fs, Path file) throws Exception,
            IOException {
	    BufferedReader reader = null;
	    try {
	    	reader = new BufferedReader(new InputStreamReader(fs.open(file)));
	    	String line = null;
	    	while((line = reader.readLine()) != null) {
	    		processor.process(line);
	    	}
	    } catch (Exception e) {
	    	throw e;
	    } finally {
	    	if(reader != null) {
	    		reader.close();
	    	}
	    }
    }
	
	public static abstract class FileProcessor {
		public abstract void process(String line);
	}
}
