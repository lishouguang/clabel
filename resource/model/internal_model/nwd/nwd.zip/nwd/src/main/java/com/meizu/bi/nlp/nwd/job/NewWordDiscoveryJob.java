package com.meizu.bi.nlp.nwd.job;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.meizu.bi.nlp.nwd.helper.Utils;
import com.meizu.bi.nlp.nwd.helper.Utils.FileProcessor;
import com.meizu.bi.nlp.nwd.job.aggregation.AggregationJob;
import com.meizu.bi.nlp.nwd.job.entropy.EntropyJob;
import com.meizu.bi.nlp.nwd.job.merge.MergeJob;

/**
 * 基于词内部凝聚度和左右邻字信息熵的自动分词算法，Hadoop的实现
 * 
 * 参考：http://www.matrix67.com/blog/archives/5044
 * 
 * hadoop jar nwd-0.0.1-SNAPSHOT.jar com.meizu.bi.nlp.nwd.job.NewWordDiscoveryJob /tmp/nwd/pinglun.min.txt /tmp/nwd/p
 * 
 * @author lishouguang
 *
 */
public class NewWordDiscoveryJob {
	
	private static final Logger logger = Logger.getLogger(NewWordDiscoveryJob.class);
	
	public static void main(String[] args) throws Exception {

		if(args.length < 2) {
			System.err.println("default env variable:\n"
					+ "    export min_aggregation=100\n"
					+ "    export min_entropy=2\n"
					+ "    export max_word_length=2\n"
					+ "usage:"
					+ "    hadoop nwd-0.0.1-SNAPSHOT.jar com.meizu.bi.nlp.nwd.job.NewWordDiscoveryJob inputpath outputpath");
			System.exit(1);
		}
		
		String inputpath = args[0];
		String outputpath = args[1];
		
		logger.info("max word length: " + Utils.getEnvMaxWordLength());
		logger.info("min entropy: " + Utils.getEnvMinEntropy());
		logger.info("min aggregation: " + Utils.getEnvMinAggregation());
		logger.info("min word freq: " + Utils.getEnvMinWordFreq());
		
		logger.info("start calculate entropy...");

		// 计算各候选词的左右邻字信息熵，最终数据文件在${outputpath}/entropy目录下
		// 输出数据格式是：[word]\t[entropy]\t[lentropy]\t[rengropy]
		String entropyDataPath = String.format("%s/entropy", outputpath);
		long entropyTotal = new EntropyJob().run(inputpath, entropyDataPath);
		if(entropyTotal == -1) {
			logger.error("entropy job failed!");
			return;
		}
		
		logger.info("start calculate aggregation...");
		
		// 计算各候选词的内部凝聚度，返回数据文件目录
		// 输出数据格式是: [word]\t[aggregation]
		String aggDataPath = new AggregationJob().run(inputpath, String.format("%s/aggregation", outputpath));
		if(aggDataPath == null) {
			logger.error("aggregation job failed!");
			return;
		}
		
		logger.info("start merge entropy and aggregation data...");
		// 合并上述两个数据，取它们的交集
		String wordDataPath = String.format("%s/word", outputpath);
		if(!new MergeJob().run(entropyDataPath, aggDataPath, wordDataPath)) {
			logger.error("merge entropy and aggregation data failed!");
			return;
		}
		
		logger.info("start obtain words.");
		final File file = new File("word");
		if(file.exists()) {
			file.delete();
			file.createNewFile();
		}
		
		Utils.iterFile(wordDataPath, new FileProcessor() {
			@Override
			public void process(String line) {
				try {
	                FileUtils.writeStringToFile(file, line + "\n", true);
                } catch (IOException e) {
	                e.printStackTrace();
                }
			}
		});
	}

}

