package com.meizu.bi.nlp.nwd.job.aggregation;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.log4j.Logger;

public class AggregationJob extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(AggregationJob.class);

	public int run(String[] args) throws Exception {
		return this.run(args[0], args[1]) != null ? 0 : 1;
	}

	public String run(String inputpath, String outputpath) throws Exception {
		
		// 统计总字数据
		long total = new WordTotalJob().run(inputpath, String.format("%s/total", outputpath));
		
		// 统计各候选词的词频
		// 在计算候选词的内部凝聚度时，需要知道候选词任意两部分的词频，所以讲词频数据保存在mapdb里，Constants.DB_FILE_NAME/Constants.DB_MAP_COUNT
		String freqOutput = String.format("%s/freq", outputpath);
		boolean success = new WordFreqJob().run(inputpath, freqOutput);
		if(!success) {
			logger.error("word freq job failed!");
			return null;
		}
		
		// 计算各候选词的内部凝聚度，最终数据在${outputpaht}/agg里
		String resultPath = String.format("%s/agg", outputpath);
		if(new WordAggregationJob().run(freqOutput, resultPath, total)) {
			return resultPath;
		}
		
		return null;
	}
	
}
