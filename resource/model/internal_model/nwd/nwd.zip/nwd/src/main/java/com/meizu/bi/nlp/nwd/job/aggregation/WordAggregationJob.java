package com.meizu.bi.nlp.nwd.job.aggregation;

import java.io.File;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.zeroturnaround.zip.ZipUtil;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;

public class WordAggregationJob extends Configured implements Tool {
	
	private static final Logger logger = Logger.getLogger(WordAggregationJob.class);

	public static void main(String[] args) throws Exception {
		ToolRunner.run(new WordAggregationJob(), args);
	}

	public int run(String[] args) throws Exception {
	    return this.run(args[0], args[1], Long.parseLong(args[2])) ? 0 : 1;
    }
	
	public boolean run(String inputpath, String outputpath, long total) throws Exception {
		Configuration conf = new Configuration();
		conf.setLong(Constants.JOB_CONF_WORD_TOTAL, total);
		conf.setDouble(Constants.JOB_CONF_MIN_AGGREGATION, Utils.getEnvMinAggregation());
		conf.setInt(Constants.JOB_CONF_MAX_WORD_LENGTH, Utils.getEnvMaxWordLength());
		conf.setInt(Constants.JOB_CONF_MIN_WORD_FREQ, Utils.getEnvMinWordFreq());

		Path input = new Path(inputpath);
		Path output = new Path(outputpath);

		// 检查输入文件
		FileSystem fs = FileSystem.get(conf);
		if (!fs.exists(input)) {
			logger.error("input path not exists!");
			System.exit(1);
		}

		// 检查输出目录
		if (fs.exists(output)) {
			logger.warn("output path exists, remove it!");
			fs.delete(output, true);
		}
		
		File dbzip = new File(Constants.DB_ROOT_ZIP);
		if(dbzip.exists()) {
			dbzip.delete();
		}
		
		ZipUtil.pack(new File(Constants.DB_ROOT), dbzip);
		
		Path hdbzip = new Path(Constants.DB_ROOT_ZIP);
		logger.info(String.format("put local file [%s] to hdfs [%s]", dbzip.getAbsolutePath(), hdbzip));

		fs.copyFromLocalFile(new Path("file://" + dbzip.getAbsolutePath()), hdbzip);

		Job job = Job.getInstance(conf, "word aggregation job");
		job.setJarByClass(WordAggregationJob.class);
		
		job.addArchiveToClassPath(hdbzip);

		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);

		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		job.setMapperClass(WordAggregationMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setReducerClass(WordAggregationReducer.class);
		
		if(!job.waitForCompletion(true)) {
			return false;
		}
		
		return true;
	}

}
