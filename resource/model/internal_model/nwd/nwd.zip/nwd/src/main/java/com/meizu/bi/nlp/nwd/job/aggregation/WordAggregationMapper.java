package com.meizu.bi.nlp.nwd.job.aggregation;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

import com.meizu.bi.nlp.nwd.helper.Constants;

public class WordAggregationMapper extends Mapper<LongWritable, Text, Text, Text> {
	
	private DB db = null;
	private HTreeMap<String, Long> map = null;
	
	private double minAggregation = -1;
	private int minWordFreq = -1;
	
	@Override
	protected void setup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException,
	        InterruptedException {
	    super.setup(context);
	    
	    this.db = DBMaker
	    		.newFileDB(new File(Constants.DB_ROOT_ZIP + File.separator + Constants.DB_NAME))
	    		.readOnly()
	    		.transactionDisable()
	    		.mmapFileEnable().make();
	    this.map = this.db.getHashMap(Constants.DB_MAP_COUNT);
	    
	    this.minAggregation = context.getConfiguration().getDouble(Constants.JOB_CONF_MIN_AGGREGATION, Constants.DEFAULT_MIN_AGGREGATION);
	    this.minWordFreq  = context.getConfiguration().getInt(Constants.JOB_CONF_MIN_WORD_FREQ, Constants.DEFAULT_MIN_WORD_FREQ);
	}
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
	        throws IOException, InterruptedException {
		String[] splited = value.toString().split("\t");
		
		String word = splited[0];
		
		if(word.length() < 2) {
			return;
		}
		
		long total = context.getConfiguration().getLong(Constants.JOB_CONF_WORD_TOTAL, 0);
		long count = Long.parseLong(splited[1]);
		
		if(count < this.minWordFreq) {
			return;
		}
		
		double p = 1.0*count/total;
		
		double zero = 1.0/total;
		double minRate = Long.MAX_VALUE;
		
		for(String[] pair : splitTwos(word)) {
			Long c1 = this.map.get(pair[0]);
			Long c2 = this.map.get(pair[1]);
			
			double p1 = c1!=null ? 1.0*c1/total : zero;
			double p2 = c2!=null ? 1.0*c2/total : zero;
			
			minRate = Math.min(minRate, p / (p1 * p2));
		}
		
		if(minRate >= this.minAggregation) {
			context.write(new Text(word), new Text(String.format("%s\t%s", count, minRate)));
		}
	}
	
	@Override
	protected void cleanup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException,
	        InterruptedException {
	    super.cleanup(context);
	    if(this.db != null) {
	    	this.db.close();
	    }
	}
	
	private List<String[]> splitTwos(String str) {
		List<String[]> list = new ArrayList<String[]>();
		for(int i=1; i<str.length(); i++) {
			list.add(new String[]{str.substring(0, i), str.substring(i)});
		}
		return list;
	}

}
