package com.meizu.bi.nlp.nwd.job.aggregation;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.mapdb.DB;
import org.mapdb.HTreeMap;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;
import com.meizu.bi.nlp.nwd.helper.Utils.FileProcessor;

public class WordFreqJob extends Configured implements Tool {
	private static final Logger logger = Logger.getLogger(WordFreqJob.class);

	public static void main(String[] args) throws Exception {
		System.exit(ToolRunner.run(new WordFreqJob(), args));
	}

	public int run(String[] args) throws Exception {
	    return run(args[0], args[1]) ? 0 : 1;
    }
	
	public boolean run(String inputpath, String outputpath) throws Exception {
		Configuration conf = new Configuration();
		conf.setInt(Constants.JOB_CONF_MAX_WORD_LENGTH, Utils.getEnvMaxWordLength());

		Path input = new Path(inputpath);
		Path output = new Path(outputpath);

		// 检查输入文件
		FileSystem fs = FileSystem.get(conf);
		if (!fs.exists(input)) {
			logger.error("input path not exists!");
			System.exit(1);
		}

		// 检查输出目录
		if (fs.exists(output)) {
			logger.warn("output path exists, remove it!");
			fs.delete(output, true);
		}

		Job job = Job.getInstance(conf, "word frequency job");
		job.setJarByClass(WordFreqJob.class);

		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);

		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		job.setMapperClass(WordFreqMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(LongWritable.class);

		job.setReducerClass(WordFreqReducer.class);
		
		if(!job.waitForCompletion(true)) {
			return false;
		}

		final DB db = Utils.openDB();
		final HTreeMap<String, Long> cmap = db.getHashMap(Constants.DB_MAP_COUNT);
		
		
		Utils.iterFile(outputpath, new FileProcessor() {
			private int i = 1;
			
			@Override
			public void process(String line) {
				String[] splited = line.split("\t");
				cmap.put(splited[0], Long.parseLong(splited[1]));
				
				i++;
				if(i % 10000 == 0) {
					db.commit();
				}
			}
		});
		
		db.commit();
		
		/*
		 * show db
		 */
		/*
		DB ddb = Utils.openDB();
		HTreeMap<String, Long> map = ddb.getHashMap(Constants.DB_MAP_COUNT);
		for(Entry<String, Long> entry: map.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
		*/

		
		return true;
	}

}
