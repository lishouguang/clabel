package com.meizu.bi.nlp.nwd.job.aggregation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;

public class WordFreqMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
	
	private static final LongWritable ONE = new LongWritable(1); 
	
	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, Text, LongWritable>.Context context)
			throws IOException, InterruptedException {
		int max_word_length = context.getConfiguration().getInt(Constants.JOB_CONF_MAX_WORD_LENGTH, Constants.DEFAULT_MAX_WORD_LENGTH);
		for(String txt: Utils.clean(value.toString()).split(" ")) {
			List<String> segments = splitSegments(txt, max_word_length);
			for(String segment: segments) {
				context.write(new Text(segment), ONE);
			}
		}
	}
	
	/**
	 * 将一段文本拆分成多段
	 * [手机不错啊。] + 2 => [手] [手机] [机] [机不] [不] [不错] [错] [错啊] [啊] [啊。] [。]
	 * @param str
	 * @param max_length
	 * @return
	 */
	private List<String> splitSegments(String str, int max_length) {
		List<String> segments = new ArrayList<String>();
		
		char[] chars = str.toCharArray();
		int last_margin = -1;
		
		for(int i=0; i<chars.length; i++) {
			for(int j=0; j<max_length; j++) {
				int eindex = Math.min(i+j+1, str.length());
				
				int margin = eindex - i;
				if(margin != last_margin) {
					segments.add(str.substring(i, eindex));
				}
				
				last_margin = margin;
			}
		}
		
		return segments;
	}
}