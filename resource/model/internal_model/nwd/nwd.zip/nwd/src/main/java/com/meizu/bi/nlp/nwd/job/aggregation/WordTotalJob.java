package com.meizu.bi.nlp.nwd.job.aggregation;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.meizu.bi.nlp.nwd.helper.Constants;

public class WordTotalJob extends Configured implements Tool {
	
	private static final Logger logger = Logger.getLogger(WordTotalJob.class);

	public static void main(String[] args) throws Exception {
		ToolRunner.run(new WordTotalJob(), args);
	}

	public long run(String inputpath, String outputpath) throws Exception {
		Configuration conf = new Configuration();
		
		Path input = new Path(inputpath);
		Path output = new Path(outputpath);
		
		FileSystem fs = FileSystem.get(conf);
		// 检查输入文件
		if (!fs.exists(input)) {
			logger.error("input path not exists!");
			System.exit(1);
		}

		// 检查输出目录
		if (fs.exists(output)) {
			logger.warn("output path exists, remove it!");
			fs.delete(output, true);
		}	
		
		Job job = Job.getInstance(conf , "char count job");
		job.setJarByClass(WordTotalJob.class);

		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);

		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		job.setMapperClass(WordTotalMapper.class);
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(NullWritable.class);
		
		job.setNumReduceTasks(0);
		
		long total = -1;
		if(job.waitForCompletion(true)) {
			total = job.getCounters().findCounter(Constants.COUNTER_GROUP, Constants.COUNTER_CHAR_TOTAL).getValue();
		}
		logger.info("total: " + total);
		return total;
	}

	public int run(String[] args) throws Exception {
		return this.run(args[0], args[1])!=-1 ? 0 : 1;
    }

}
