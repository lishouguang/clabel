package com.meizu.bi.nlp.nwd.job.aggregation;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;

public class WordTotalMapper extends Mapper<LongWritable, Text, NullWritable, NullWritable> {
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, NullWritable, NullWritable>.Context context)
	        throws IOException, InterruptedException {
		int charCount = Utils.clean(value.toString()).replaceAll(" ", "").length();
		context.getCounter(Constants.COUNTER_GROUP, Constants.COUNTER_CHAR_TOTAL).increment(charCount);
	}
}
