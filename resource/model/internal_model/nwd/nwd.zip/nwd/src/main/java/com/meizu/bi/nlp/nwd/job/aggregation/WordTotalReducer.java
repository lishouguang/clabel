package com.meizu.bi.nlp.nwd.job.aggregation;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WordTotalReducer extends Reducer<Text, LongWritable, LongWritable, NullWritable> {
	@Override
	protected void reduce(Text key, Iterable<LongWritable> values,
	        Reducer<Text, LongWritable, LongWritable, NullWritable>.Context context) throws IOException, InterruptedException {
		long sum = 0;
		for(LongWritable c: values) {
			sum += c.get();
		}
		context.write(new LongWritable(sum), NullWritable.get());
	}
}
