package com.meizu.bi.nlp.nwd.job.entropy;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;

public class EntropyJob extends Configured implements Tool {
	
	private static final Logger logger = Logger.getLogger(EntropyJob.class);

	public int run(String[] args) throws Exception {
		return this.run(args[0], args[1]) != -1 ? 0 : 1;
	}
	
	public long run(String inputpath, String outputpath) throws Exception {
		
		Configuration conf = new Configuration();
		conf.setDouble(Constants.JOB_CONF_MIN_ENTROPY, Utils.getEnvMinEntropy());
		conf.setInt(Constants.JOB_CONF_MAX_WORD_LENGTH, Utils.getEnvMaxWordLength());
		conf.setInt(Constants.JOB_CONF_MIN_WORD_FREQ, Utils.getEnvMinWordFreq());
		
		Path input = new Path(inputpath);
		Path output = new Path(outputpath);
		
		// 检查输入文件
		FileSystem fs = FileSystem.get(conf);
		if(!fs.exists(input)) {
			logger.error("input path not exists!");
			System.exit(1);
		}
		
		// 检查输出目录
		if(fs.exists(output)) {
			logger.warn("output path exists, remove it!");
			fs.delete(output, true);
		}
		
		Job job = Job.getInstance(conf, "calculate entropy job");
		job.setJarByClass(EntropyJob.class);
		
		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);
		
		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);
		
		job.setMapperClass(EntropyMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setReducerClass(EntropyReducer.class);
		
		if(job.waitForCompletion(true)) {
			return job.getCounters().findCounter(Constants.COUNTER_GROUP, Constants.COUNTER_ENTROPY_TOTAL).getValue();
		}
		
		return -1;
	}

	public static void main(String[] args) throws Exception {
	    System.exit(ToolRunner.run(new EntropyJob() , args));
    }
}
