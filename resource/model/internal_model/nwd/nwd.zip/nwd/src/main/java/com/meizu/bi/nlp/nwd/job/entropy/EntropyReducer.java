package com.meizu.bi.nlp.nwd.job.entropy;

import java.io.IOException;
import java.util.Map.Entry;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Counter;

public class EntropyReducer extends Reducer<Text, Text, Text, Text> {
	
	private static final Logger logger = Logger.getLogger(EntropyReducer.class);
	
	private double minEntropy = -1;

	@Override
	protected void setup(Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
	    super.setup(context);
	    this.minEntropy = context.getConfiguration().getDouble(Constants.JOB_CONF_MIN_ENTROPY, Constants.DEFAULT_MIN_ENTROPY);
	    
	}
	
	@Override
	protected void reduce(Text key, Iterable<Text> values,
			Reducer<Text, Text, Text, Text>.Context context) throws IOException,
			InterruptedException {
		Counter lcounter = new Counter();
		Counter rcounter = new Counter();
		
		for(Text value: values) {
			String[] splited = value.toString().split("\t");
			//TODO 句首、句尾的处理
			lcounter.update(splited[0]);
			rcounter.update(splited[1]);
		}
		
		double lentropy = getEntropy(lcounter);
		double rentropy = getEntropy(rcounter);
		double entropy = Math.min(lentropy, rentropy);
		
		/*
		if("屏幕".equals(key.toString())) {
			StringBuffer sb = new StringBuffer();
			for(Entry<String, Long> entry: lcounter.entrySet()) {
				sb.append(entry.getKey() + ":" + entry.getValue() + ", ");
			}
			logger.info("----lcounter----" + lcounter.sum() + ", " + lentropy);
			logger.info(sb);
			
			 sb = new StringBuffer();
			for(Entry<String, Long> entry: rcounter.entrySet()) {
				sb.append(entry.getKey() + ":" + entry.getValue() + ", ");
			}
			logger.info("----rcounter----" + rcounter.sum() + ", " + rentropy);
			logger.info(sb);
		}
		*/
		
		if(key.toString().length()>1 && entropy>=this.minEntropy) {
			context.getCounter(Constants.COUNTER_GROUP, Constants.COUNTER_ENTROPY_TOTAL).increment(1);
			context.write(key, new Text(String.format("%s\t%s\t%s", entropy, lentropy, rentropy)));
		}
	}

	private double getEntropy(Counter counter) {
		double entropy = 0;

		long sum = counter.sum();
		for(Entry<String, Long> entry: counter.entrySet()) {
			double p = 1.0 * entry.getValue() / sum;
			entropy += -1 * p * Math.log(p);
		}
		
		return entropy;
	}
}
