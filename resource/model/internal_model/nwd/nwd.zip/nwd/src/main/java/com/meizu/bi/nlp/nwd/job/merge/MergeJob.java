package com.meizu.bi.nlp.nwd.job.merge;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

public class MergeJob extends Configured implements Tool{
	
	private static final Logger logger = Logger.getLogger(MergeJob.class);

	public int run(String[] args) throws Exception {
	    return this.run(args[0], args[1], args[2]) ? 0 : -1;
    }

	public boolean run(String entropyDataPath, String aggregationDataPath, String wordDataPath) throws Exception {
		Configuration conf = new Configuration();
		
		Path entropyPath = new Path(entropyDataPath);
		Path aggregationPath = new Path(aggregationDataPath);
		Path wordPath = new Path(wordDataPath);
		
		// 检查输入文件
		FileSystem fs = FileSystem.get(conf);
		
		if(!fs.exists(entropyPath)) {
			logger.error("entropy data path path not exists!");
			System.exit(1);
		}
		
		if(!fs.exists(aggregationPath)) {
			logger.error("aggregation data path path not exists!");
			System.exit(1);
		}
		
		// 检查输出目录
		if(fs.exists(wordPath)) {
			logger.warn("output word Path path exists, remove it!");
			fs.delete(wordPath, true);
		}
		
		Job job = Job.getInstance(conf, "merge data job");
		job.setJarByClass(MergeJob.class);
		
		MultipleInputs.addInputPath(job, entropyPath, TextInputFormat.class, MergeEntropyMapper.class);
		MultipleInputs.addInputPath(job, aggregationPath, TextInputFormat.class, MergeAggregationMapper.class);
		
		FileOutputFormat.setOutputPath(job, wordPath);
		
		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setReducerClass(MergeReducer.class);
		
		return job.waitForCompletion(true);
	}
	
	public static void main(String[] args) throws Exception {
		ToolRunner.run(new MergeJob(), args);
	}
}
