package com.meizu.bi.nlp.nwd.job.merge;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MergeReducer extends Reducer<Text, Text, Text, Text> {

	@Override
	protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, Text>.Context context)
	        throws IOException, InterruptedException {
		
		int freq = -1;
		double entropy = -1;
		double aggregation = -1;
		
		for(Text value: values) {
			String[] splited = value.toString().split("_");
			if("a".equals(splited[0])) {
				freq = Integer.parseInt(splited[1]);
				aggregation = Double.parseDouble(splited[2]);
			} else if ("e".equals(splited[0])) {
				entropy = Double.parseDouble(splited[1]);
			}
		}
		
		if(freq!=-1 && entropy!=-1 && aggregation!=-1) {
			context.write(key, new Text(String.format("%s\t%s\t%s", freq, entropy, aggregation)));
		}
	}
}
