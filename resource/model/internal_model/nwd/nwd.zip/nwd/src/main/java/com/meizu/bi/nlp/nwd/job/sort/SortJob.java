package com.meizu.bi.nlp.nwd.job.sort;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.partition.TotalOrderPartitioner;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

public class SortJob extends Configured implements Tool {
	private static final Logger logger = Logger.getLogger(SortJob.class);
	
	public static final String JOB_CONF_SORT_FIELD_COLNUM = "sort.field.colnum";

	public static void main(String[] args) throws Exception {
		System.exit(ToolRunner.run(new SortJob(), args));
	}

	public int run(String[] args) throws Exception {
	    return run(args[0], args[1], Integer.parseInt(args[2])) ? 0 : 1;
    }
	
	public boolean run(String inputpath, String outputpath, int sortFiledColNum) throws Exception {
		Configuration conf = new Configuration();
		conf.setInt(JOB_CONF_SORT_FIELD_COLNUM, sortFiledColNum);

		Path input = new Path(inputpath);
		Path output = new Path(outputpath);

		// 检查输入文件
		FileSystem fs = FileSystem.get(conf);
		if (!fs.exists(input)) {
			logger.error("input path not exists!");
			System.exit(1);
		}

		// 检查输出目录
		if (fs.exists(output)) {
			logger.warn("output path exists, remove it!");
			fs.delete(output, true);
		}

		Job job = Job.getInstance(conf, "sort job");
		job.setJarByClass(SortJob.class);

		job.setMapSpeculativeExecution(false);
		job.setReduceSpeculativeExecution(false);

		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		job.setMapperClass(SortMapper.class);
		job.setMapOutputKeyClass(DoubleWritable.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setPartitionerClass(TotalOrderPartitioner.class);

		job.setNumReduceTasks(1);
		job.setReducerClass(SortReducer.class);
		
		if(!job.waitForCompletion(true)) {
			return false;
		}
		
		return true;
	}

}
