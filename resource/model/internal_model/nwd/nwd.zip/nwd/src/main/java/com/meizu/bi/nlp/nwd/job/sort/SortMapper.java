package com.meizu.bi.nlp.nwd.job.sort;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SortMapper extends Mapper<LongWritable, Text, DoubleWritable, Text> {
	
	private int sortFieldColNum = -1;

	@Override
	protected void setup(Mapper<LongWritable, Text, DoubleWritable, Text>.Context context) throws IOException,
	        InterruptedException {
	    super.setup(context);
	    this.sortFieldColNum = context.getConfiguration().getInt(SortJob.JOB_CONF_SORT_FIELD_COLNUM, 1);
	}
	
	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, DoubleWritable, Text>.Context context)
			throws IOException, InterruptedException {
		String[] splited = value.toString().split("\t");
		double d = Double.parseDouble(splited[this.sortFieldColNum-1]);
		context.write(new DoubleWritable(d*-1), value);
	}
	
}