package com.meizu.bi.nlp.nwd.test;

public class Test {

	public static void main(String[] args) {
		System.out.println("abc abc abc".replaceAll(" ", ""));
	}

}
