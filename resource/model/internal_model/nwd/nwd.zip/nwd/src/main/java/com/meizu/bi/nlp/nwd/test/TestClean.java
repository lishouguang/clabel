package com.meizu.bi.nlp.nwd.test;

import java.util.ArrayList;
import java.util.List;


public class TestClean {

	public static void main(String[] args) {
		String CLEAN_REG_STR = "[\\s,.<>\\?:;'\"\\[\\]\\{\\}\\(\\|)~!@#$%^&*\\-_=+，。《》、？：；“”‘’｛｝【】（）…￥！—┄－]+";
		
		String value = "看电影的时候自动闪屏重启一次；游戏的时候偶然卡住，一次黑屏死机，手动才开机的";
		String line = value.toString().replaceAll(CLEAN_REG_STR, " ");
		for(String txt: line.trim().split(" ")) {
			List<String> segments = splitSegments(txt, 2);
			for(String segment: segments) {
				System.out.println(segment);
			}
		}
	}
	
	/**
	 * 将一段文本拆分成多段
	 * [手机不错啊。] + 2 => [手] [手机] [机] [机不] [不] [不错] [错] [错啊] [啊] [啊。] [。]
	 * @param str
	 * @param max_length
	 * @return
	 */
	private static List<String> splitSegments(String str, int max_length) {
		List<String> segments = new ArrayList<String>();
		
		char[] chars = str.toCharArray();
		int last_margin = -1;
		
		for(int i=0; i<chars.length; i++) {
			for(int j=0; j<max_length; j++) {
				int eindex = Math.min(i+j+1, str.length());
				
				int margin = eindex - i;
				if(margin != last_margin) {
					segments.add(str.substring(i, eindex));
				}
				
				last_margin = margin;
			}
		}
		
		return segments;
	}

}
