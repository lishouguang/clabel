package com.meizu.bi.nlp.nwd.test;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import jdbm.PrimaryHashMap;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.SecondaryHashMap;
import jdbm.SecondaryKeyExtractor;

public class TestJDBM {
	
	class MyKeyComparator implements Comparator<String>, Serializable {
        private static final long serialVersionUID = 1L;

		public int compare(String str1, String str2) {
			double d1 = Double.parseDouble(str1.split("\t")[1]);
			double d2 = Double.parseDouble(str2.split("\t")[1]);
			
			if(d1 == d2) {
				return 0;
			} else if(d2 > d1) {
				return 1;
			} else {
				return -1;
			}
        }
		
	}

	public static void main(String[] args) throws Exception {
		List<String> lines = new ArrayList<String>();
		
		lines.add("手机\t0.2314");
		lines.add("魅族\t1.2314");
		lines.add("屏幕\t0.3312314");
		lines.add("CPU\t0.1314");
		lines.add("NFC\t2.4");
		
		RecordManager recMan = RecordManagerFactory.createRecordManager("db" + File.separator + "xx.db");
		
		PrimaryTreeMap<String, String> main = recMan.treeMap("treemap", new Comparator<String>() {

			public int compare(String str1, String str2) {
				double d1 = Double.parseDouble(str1.split("\t")[1]);
				double d2 = Double.parseDouble(str2.split("\t")[1]);
				
				if(d1 == d2) {
					return 0;
				} else if(d2 > d1) {
					return 1;
				} else {
					return -1;
				}
	        }
			
		});
		
		SecondaryHashMap<String, String, String> index = main.secondaryHashMap("index", new SecondaryKeyExtractor<String, String, String>() {
			public String extractSecondaryKey(String key, String value) {
	            return key.split("\t")[0];
            }
		});
		
		for(String line: lines) {
			main.put(line, line.split("\t")[1]);
		}
		
		String xx = index.getPrimaryValue("手机");
		System.out.println(xx);
		
		recMan.commit();
		recMan.close();
		
	}

}
