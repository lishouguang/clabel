package com.meizu.bi.nlp.nwd.test;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Map.Entry;
import java.util.Set;

import jdbm.PrimaryStoreMap;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.SecondaryHashMap;
import jdbm.SecondaryKeyExtractor;

public class TestJDBM2 {
	
	public void test2() throws IOException {
		RecordManager recMan = RecordManagerFactory.createRecordManager("db" + File.separator + "word.db");
		
		PrimaryStoreMap<Long, WordValue> main = recMan.storeMap("wordcount");
		
		SecondaryHashMap<String, Long, WordValue> wordIndex = main.secondaryHashMap("wordindex", new SecondaryKeyExtractor<String, Long, WordValue>() {
			public String extractSecondaryKey(Long key, WordValue value) {
	            return value.getWord();
            }
		});
		
		main.putValue(new WordValue("手机", 100.0));
		main.putValue(new WordValue("屏幕", 50.0));
		main.putValue(new WordValue("摄像头", 200.0));
		main.putValue(new WordValue("CPU", 60.0));
		
		for(String widx : wordIndex.keySet()) {
			System.out.println(widx + ": " + wordIndex.get(widx) + " -> " + wordIndex.getPrimaryValues(widx).iterator().next());
		}
		
		System.out.println("------------------");
	}
	
	public void test() throws IOException {
		RecordManager recMan = RecordManagerFactory.createRecordManager("db" + File.separator + "word.db");
		
		PrimaryTreeMap<String, Double> main = recMan.treeMap("word_count", new WordValueComparator());
		
		SecondaryHashMap<String, String, Double> wordIndex = main.secondaryHashMap("wordindex", new SecondaryKeyExtractor<String, String, Double>() {
			public String extractSecondaryKey(String key, Double value) {
	            return key.split("\001")[0];
            }
		});
		
		main.put("手机\001100", 100.0);
		main.put("屏幕\00150", 50.0);
		main.put("摄像头\001200", 200.0);
		main.put("CPU\00160", 60.0);
		
		System.out.println(main.entrySet());
		System.out.println(wordIndex.entrySet());
		
		System.out.println("--------get----------");
		System.out.println(wordIndex.getPrimaryValues("手机").iterator().next());
	}

	public static void main(String[] args) throws Exception {
		new TestJDBM2().test();
	}

}

class WordValue implements Serializable {

    private static final long serialVersionUID = 1L;
	
    private String word = null;
    private Double value = null;
    
	public WordValue(String word, Double value) {
	    super();
	    this.word = word;
	    this.value = value;
    }
	
	@Override
	public String toString() {
		return String.format("word: %s, value: %s", this.word, this.value);
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}
}

class WordValueComparator implements Comparator<String>, Serializable {

    private static final long serialVersionUID = 1L;

	public int compare(String o1, String o2) {
		String[] splited1 = o1.split("\001");
		String[] splited2 = o2.split("\001");

		String word1 = splited1[0];
		String word2 = splited2[0];
		
		double d1 = Double.parseDouble(splited1[1]);
		double d2 = Double.parseDouble(splited2[1]);
		
		if(d1 == d2) {
			return word1.compareTo(word2);
		} else if(d1 > d2) {
			return -1;
		} else {
			return 1;
		}
    }
}
