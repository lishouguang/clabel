package com.meizu.bi.nlp.nwd.test;

import java.io.File;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

public class TestMapDB {

	public static void main(String[] args) {
		DB db = DBMaker
				.newFileDB(new File("mapdb" + File.separator + "file2.db"))
				.transactionDisable()
				.mmapFileEnable()
				.make();
		
		HTreeMap<String, Long> map = db.getHashMap("testmap");
		
		map.put("hello", 1l);
		map.put("a", 2l);
		map.put("b", 3l);
		db.commit();
		
		System.out.println(map.get("hello"));
		System.out.println(map.get("a"));
		System.out.println(map.get("b"));
		
		db.close();
	
	}
	
}

