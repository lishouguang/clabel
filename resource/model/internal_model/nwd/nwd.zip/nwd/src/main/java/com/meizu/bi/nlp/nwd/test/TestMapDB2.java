package com.meizu.bi.nlp.nwd.test;

import java.io.File;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

import com.meizu.bi.nlp.nwd.helper.Constants;
import com.meizu.bi.nlp.nwd.helper.Utils;

public class TestMapDB2 {

	public static void main(String[] args) {
		DB db = DBMaker
				.newFileDB(new File(Constants.DB_FILE_NAME))
				.transactionDisable()
				.mmapFileEnable()
				.make();
		
		HTreeMap<String, Long> map = db.getHashMap(Constants.DB_MAP_COUNT);
//		map.put("hello", 1l);
//		map.put("a", 2l);
//		map.put("b", 3l);
//		db.commit();
		
		System.out.println(map.get("hello"));
		System.out.println(map.get("a"));
		System.out.println(map.get("b"));
		
		
		db.close();
		
	}
	
}

