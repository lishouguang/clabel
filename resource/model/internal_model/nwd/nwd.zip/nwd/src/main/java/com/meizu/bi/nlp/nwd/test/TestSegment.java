package com.meizu.bi.nlp.nwd.test;

import java.util.ArrayList;
import java.util.List;

public class TestSegment {

	public static void main(String[] args) {
		int max_length = 3;
		
		String str = "手机不错123";
		
		List<String> segments = spliteSegments(max_length, str);
		for(String s : segments) {
			System.out.println(s);
		}
		
	}

	private static List<String> spliteSegments(int max_length, String str) {
		List<String> segments = new ArrayList<String>();
		
		char[] chars = str.toCharArray();
		
		int last_margin = -1;
		
		for(int i=0; i<chars.length; i++) {
			
			for(int j=0; j<max_length; j++) {
				
				int eindex = Math.min(i+j+1, str.length());
				
				int margin = eindex - i;
				if(margin != last_margin) {
					segments.add(str.substring(i, eindex));
				}
				
				last_margin = margin;
			}
		}
		
		return segments;
	}

}
