package com.meizu.bi.nlp.nwd.test;

import java.util.ArrayList;
import java.util.List;

public class TestSegmentLeft {

	public static void main(String[] args) {
		int max_length = 3;
		
		String str = "手机不错";
		
		System.out.println(str);
		
		System.out.println("--------------");
		
		List<String[]> segments = spliteSegmentsWithNeighbors(max_length, str);
		for(String[] tuple : segments) {
			System.out.println(String.format("%s: %s, %s", tuple[1], tuple[0], tuple[2]));
		}
		
	}

	private static List<String[]> spliteSegmentsWithNeighbors(int max_length, String str) {
		List<String[]> segments = new ArrayList<String[]>();
		
		char[] chars = str.toCharArray();
		
		int last_margin = -1;
		
		for(int i=0; i<chars.length; i++) {
			
			for(int j=0; j<max_length; j++) {
				
				int eindex = Math.min(i+j+1, str.length());
				
				int margin = eindex - i;
				if(margin != last_margin) {
					String segment = str.substring(i, eindex);
					String left = (i-1)<0 ? null : str.substring(i-1, i);
					String right = (eindex+1)>str.length() ? null: str.substring(eindex, eindex+1);
					segments.add(new String[]{left, segment, right});
				}
				
				last_margin = margin;
			}
		}
		
		return segments;
	}

}
