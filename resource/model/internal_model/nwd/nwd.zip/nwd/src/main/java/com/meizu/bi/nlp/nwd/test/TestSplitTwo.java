package com.meizu.bi.nlp.nwd.test;

import java.util.ArrayList;
import java.util.List;

public class TestSplitTwo {

	public static void main(String[] args) {
		String str = "你好";
		
		List<String[]> list = splitTwos(str);
		for(String[] two: list) {
			System.out.println(String.format("%s__%s", two[0], two[1]));
		}
	}

	private static List<String[]> splitTwos(String str) {
		List<String[]> list = new ArrayList<String[]>();
		for(int i=1; i<str.length(); i++) {
			list.add(new String[]{str.substring(0, i), str.substring(i)});
		}
		return list;
	}

}
