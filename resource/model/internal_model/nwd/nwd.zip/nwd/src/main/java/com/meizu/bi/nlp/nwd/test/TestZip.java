package com.meizu.bi.nlp.nwd.test;

import java.io.File;

import org.zeroturnaround.zip.ZipUtil;

public class TestZip {

	public static void main(String[] args) throws Exception {
		File db = new File("db");
		ZipUtil.pack(db, new File("db.zip"));
	}

}
