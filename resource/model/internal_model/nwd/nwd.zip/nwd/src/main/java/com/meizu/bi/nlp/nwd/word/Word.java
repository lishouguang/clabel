package com.meizu.bi.nlp.nwd.word;

public class Word {

	private String word;
	private double aggregation;
	
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public double getAggregation() {
		return aggregation;
	}
	public void setAggregation(double aggregation) {
		this.aggregation = aggregation;
	}
	
}
